<?php

require 'connection.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imie_klienta = $_POST["imie_klienta"];
    $godzina_rezerwacji = $_POST["godzina_rezerwacji"];
    $data_rezerwacji = $_POST["data_rezerwacji"];
    $id_stolika = intval($_POST["id_stolika"]);
}

$select_query_pojemnosc = "SELECT pojemnosc FROM stoliki WHERE id_stolika='$id_stolika'";
$rezultat_pojemnosc = mysqli_query($conn, $select_query_pojemnosc);

$id_rezerwacji = intval($godzina_rezerwacji) . intval($data_rezerwacji);

$test_insert = "INSERT INTO rezerwacje (id_stolika, id_rezerwacji, imie, godzina_rezerwacji, data_rezerwacji)
    VALUES ('$id_stolika', '$id_rezerwacji', '$imie_klienta', '$godzina_rezerwacji', '$data_rezerwacji');";

mysqli_query($conn, $test_insert);

?>